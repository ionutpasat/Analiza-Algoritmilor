#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int N;

void print(int mat[]);
void place_queen(int mat[], int linie);
int check(int mat[], int linie, int coloana);

void place_queen(int mat[N], int linie)
{
    /* daca N regine au fost plasate printez solutia si ies */
    if (linie == N)
    {
        print(mat);
        exit(EXIT_SUCCESS);
    }

    /*
    *mut regina pe casute consecutive ale liniei 'linie'
    *si apelez recursiv pentru fiecare mutare valida
    */
    for (int j = 0; j < N; j++)
    {
        /* daca nicio regina nu se ataca */
        if (check(mat, linie, j))
        {
            /* pun regina pe casuta curenta */
            mat[linie * N + j] = 1;
            /* apelez recursiv pentru urmatoarea linie */
            place_queen(mat, linie + 1);
            /* backtracking pentru a scoate regina de pe casuta curenta */
            mat[linie * N + j] = 0;
        }
    }
}

/*
*verificarea o fac pt linia curenta doar in sus, deoarece stiu ca mai jos
*de linia curenta sau chiar pe aceasta nu se afla nicio regina deocamdata
*/
int check(int mat[N], int linie, int coloana)
{
    int i = linie, j = coloana;
    /* returnez 0 daca 2 regine sunt pe ac. coloana */
    for (int i = 0; i < linie; i++)
        if (mat[i * N + coloana] == 1)
            return 0;

    i = linie, j = coloana;
    /* returnez 0 daca sunt 2 regine pe diagonala principala */
    while (i >= 0 && j >= 0)
    {
        if (mat[i * N + j] == 1)
            return 0;
        i--;
        j--;
    }

    i = linie;
    j = coloana;
    /* returnez 0 daca sunt 2 regine pe diagonala secundara */
    while (i >= 0 && j < N)
    {
        if (mat[i * N + j] == 1)
            return 0;
        i--;
        j++;
    }

    return 1;
}


/* 
*functie de printare a unei matrice si a perechilor 
*de indici pe care e afla reginele
*/
void print(int mat[N])
{
    printf("\n");
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            printf("%d ", mat[i * N + j]);
        }
        printf("\n");
    }
    printf("\n");
    printf("Pozitiile pe care se afla reginele sunt:\n");
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            if (mat[i * N + j] == 1)
                printf("%d %d\n", i, j);
        }
    }
}

int main()
{
    scanf("%d", &N);
    int mat[N * N];

    for (int i = 0; i < N * N; i++)
        mat[i] = 0;

    place_queen(mat, 0);

    return 0;
}