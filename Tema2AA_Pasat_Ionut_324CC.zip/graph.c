#include <stdio.h>
#include <stdlib.h>
#define MAX 20
#define MAX_SUB 5000

int x[100], v[100],  linie = 0;
/* structura de graf */
struct Graf
{
    int sub_count;
    int N;
    int K2;
    int mat[MAX][MAX];
    int subgraph[MAX_SUB][20];
    struct Graf *next;
};

/* fucntie ce initializeaza un graf */
struct Graf *getnewGraph(int N, int K2)
{
    struct Graf *graf;
    graf = (struct Graf *)malloc(sizeof(struct Graf));
    graf->next = NULL;
    graf->N = N;
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
        {
            graf->mat[i][j] = 0;
        }
    for (int i = 0; i < MAX_SUB; i++)
        for (int j = 0; j < K2; j++)
        {
            graf->subgraph[i][j] = 0;
        }
    return graf;
}

/* functie ce returneaza factorialul unui nr. */
int factorial(int n)
{
    int rez = 1;
    for (int i = 1; i <= n; i++)
        rez *= i;
    return rez;
}


/*
*functie care scrie linie cu linie cate un aranjament de dim. K2 in 
*matricea tuturor aranjamentelor unui graf cu N noduri
 */
void assign_perm(int m, struct Graf *graf)
{
    for (int i = 0; i < m; i++)
    {
        graf->subgraph[linie][i] = x[i];
    }
    linie++;
}

/* functie care verifica daca un element se afla deja in vector */
int valid(int k)
{
    for (int i = 0; i < k; i++)
        if (x[i] == x[k])
            return 0;
    return 1;
}

/* functie ce produce un aranjament de n luat cate m */
void back(int k, int n, int m, struct Graf *graf)
{
    for (int i = 0; i < n; i++)
    {
        x[k] = i;
        if (valid(k))
        {
            if (k == m - 1)
                /* 
                *daca am gasit un aranjament valid il scriu
                *in matricea de aranjamente a grafului
                 */
                assign_perm(m, graf);
            else
                back(k + 1, n, m, graf);
        }
    }
}
/* functie ce adauga muchii in matricea de adiacenta a unui graf */
void add_edges(struct Graf *graf, int m1, int m2)
{
    graf->mat[m1][m2] = 1;
    graf->mat[m2][m1] = 1;
}

/* fucntie care testeaza daca 2 matrici sunt identice */
int test_matrix(int n, int mat1[n][n], int mat2[n][n])
{
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
        {
            if (mat1[i][j] != mat2[i][j])
                return 0;
        }
    return 1;
}

int create_sub_matrices(int K, int K2, struct Graf *first)
{
    int contor = 0;
    struct Graf *aux = first;
    int mat1[K2][K2];
    int mat2[K2][K2];
    for (int l = 0; l < first->sub_count; l++)
    {
        int k = 0;
        /* pt. fiecare aranjament din graful 1 construiesc matricea de ad. */
        for (int i = 0; i < K2; i++)
        {
            v[k] = first->subgraph[l][i];
            k++;
            for (int j = 0; j < K2; j++)
            {
                mat1[i][j] = first->mat[first->subgraph[l][i]][first->subgraph[l][j]];
            }
        }
        aux = first->next;
        for (int l2 = 0; l2 < aux->sub_count && aux != NULL; l2++)
        {
            /* 
            *pt. fiecare aranjament din grafurile urmatoare construiesc 
            *matricea de ad. si compar cu primul graf
            */
            for (int i2 = 0; i2 < K2; i2++)
            {
                for (int j2 = 0; j2 < K2; j2++)
                {
                    mat2[i2][j2] = aux->mat[aux->subgraph[l2][i2]][aux->subgraph[l2][j2]];
                }
            }
            /* 
            *daca am gasit 2 subgrafuri izomorfe intre primul graf si al 2 lea de
            *exemplu, trec la a compara acel subgraf cu cele din al 3 lea graf si tot asa
             */
            if (test_matrix(K2, mat1, mat2))
            {
                for (int k2 = 0; k2 < K2; k2++)
                {
                    v[k] = aux->subgraph[l2][k2];
                    k++;
                }
                contor++;
                /* daca am gasit un subgraf izomorf pt toate grafurile returnez 1 */
                if (contor == (K - 1))
                {
                    return 1;
                }
                aux = aux->next;
                l2 = 0;
            }
        }
        /* 
        *resetez verificarea daca nu s-a gasit niciun subgraf din graful 2
        *izomorf cu subgraful verificat curent din graful 1
         */
        contor = 0;
    }
    return 0;
}

int main()
{
    struct Graf *first_graf;
    int K, K2, N, m1, m2, k;
    printf("Introduceti nr. de grafuri: ");
    scanf("%d", &K);
    k = K;
    if (K == 0 || K == 1)
    {
        printf("Nr. de grafuri invalid!\n");
        exit(EXIT_SUCCESS);
    }
    printf("Introduceti dimensiunea subgrafurilor: ");
    scanf("%d", &K2);
    if (K2 == 0 || K2 == 1)
    {
        printf("Toate grafurile sunt izomorfe.");
        exit(EXIT_SUCCESS);
    }
    printf("Introduceti nr. de noduri din graful curent: ");
    scanf("%d", &N);
    /* definesc intai primul graf */
    first_graf = getnewGraph(N, K2);
    struct Graf *aux = first_graf;
    printf("Introduceti perechile de muchii [(-1 -1) pt. a iesi]: \n");
    while (1)
    {
        scanf("%d %d", &m1, &m2);
        if (m1 == -1 && m2 == -1)
            break;
        add_edges(first_graf, m1, m2);
    }
    /*
    *pentru fiecare graf pastrez dimensiunea subgrafurilor, nr. de aranjamente
    *al subgrafurilor de dimensiune K2 si o matrice cu toate acestea
     */
    first_graf->K2 = K2;
    back(0, N, K2, first_graf);
    first_graf->sub_count = N * (factorial(N - 1) / factorial(N - K2));
    linie = 0;
    k--;
    while (k)
    {
        struct Graf *next_graf;
        printf("Introduceti nr. de noduri din graful curent: ");
        scanf("%d", &N);
        next_graf = getnewGraph(N, K2);
        aux->next = next_graf;
        aux = next_graf;
        printf("Introduceti perechile de muchii [(-1 -1) pt. a iesi]: \n");
        while (1)
        {
            scanf("%d %d", &m1, &m2);
            if (m1 == -1 && m2 == -1)
                break;
            add_edges(next_graf, m1, m2);
        }
        next_graf->K2 = K2;
        back(0, N, K2, next_graf);
        next_graf->sub_count = N * (factorial(N - 1) / factorial(N - K2));
        linie = 0;
        k--;
    }

    /* 
    *Daca grafuurile sunt izomorfe afisez mesaj si nodurile subgrafurilor
    *din fiecare graf care au adeverit propozitia
     */
    if (create_sub_matrices(K, K2, first_graf))
    {
        printf("\nGrafurile sunt izomorfe.\n");
        int contor = 0;
        for (int i = 0; i < K * K2; i++)
        {
            contor++;
            printf("%d ", v[i]);
            if (contor % K2 == 0)
                printf("\n");
        }
    }
    else
        printf("\nGrafurile nu sunt izomorfe.\n");

    return 0;
}

//Complexitate: O(K2^2 * produs (i = 1...K) [Ni!/(Ni-K2)!])